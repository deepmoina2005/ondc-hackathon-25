# Code Citations

## License: unknown
https://github.com/nanangassa/FlutterApp/tree/4c8067204c71f53036ee8b5fe4aeffede17a44ef/test_driver/app_test.dart

```
Verify that our counter starts at 0.
    expect(find.text('0'), findsOneWidget);
    expect(find.text('1'), findsNothing);

    // Tap the '+' icon and trigger a frame.
    await tester.tap(find
```


## License: unknown
https://github.com/kchnr/incubator/tree/e9cc6ebf8a4d230a1f45341de3a84a88cdcecc3e/flutter/share_with_test/test/widget_test.dart

```
increments smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(MyApp());

    // Verify that our counter starts at 0.
    expect(find.text('0'), findsOneWidget);
```


## License: unknown
https://github.com/inqbator/memester/tree/b59086aefbb00370c164f2c455241099399b129a/test/widget_test.dart

```
'Counter increments smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(MyApp());

    // Verify that our counter starts at 0.
    expect(find.text('0'), findsOneWidget
```


## License: unknown
https://github.com/akshatkumar-dev/flutter-AgroBook/tree/2513a665c80903198c316481aa8d1c48bceefa7c/test/widget_test.dart

```
(WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(MyApp());

    // Verify that our counter starts at 0.
    expect(find.text('0'), findsOneWidget);
    expect(find.text
```


## License: unknown
https://github.com/evisalumani/demo_app/tree/daa7ab2523c7a71f23e1be5413ac9611c79666f6/test/widget_test.dart

```
('Counter increments smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(MyApp());

    // Verify that our counter starts at 0.
    expect(find.text('0'),
```

