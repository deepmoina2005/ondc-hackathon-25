package com.example.apex_code_ki_dukaan_flutter_vscode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
