# Code Citations

## License: BSD_3_Clause
https://github.com/firebase/flutterfire/tree/925f560e97d14590e39721d02de3c33828cb1f00/packages/firebase_ml_model_downloader/firebase_ml_model_downloader/example/lib/main.dart

```
) async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
```


## License: unknown
https://github.com/sametcilingir/Online-Tombala/tree/9c659dd4a34a564e6c8f5aac56bcaf1236f4a04a/lib/main.dart

```
;
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState(
```


## License: unknown
https://github.com/Bobby-Anggunawan/MW-B-Salties/tree/74dd9975f87bb43238a8eeb036f49e98a02522f5/lib/main.dart

```
.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState()
```


## License: unknown
https://github.com/deanbot/intl-poc/tree/3792754019cb5812bee75b3226a363529547a0e2/gen_i18n/lib/main.dart

```
(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Locale _locale = const
```

