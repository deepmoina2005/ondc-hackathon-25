import 'package:flutter/material.dart';

class CheckoutPage extends StatelessWidget {
  final List<Map<String, dynamic>> cartItems = [
    {'name': 'Product 1', 'price': 100},
    {'name': 'Product 2', 'price': 200},
  ]; // Replace with actual cart data

  @override
  Widget build(BuildContext context) {
    double totalPrice = cartItems.fold(0, (sum, item) => sum + item['price']);

    return Scaffold(
      appBar: AppBar(title: Text('Checkout')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: cartItems.length,
                itemBuilder: (context, index) {
                  final item = cartItems[index];
                  return ListTile(
                    title: Text(item['name']),
                    subtitle: Text('Price: ₹${item['price']}'),
                  );
                },
              ),
            ),
            Text('Total: ₹$totalPrice',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigate to payment or confirm order
              },
              child: Text('Proceed to Pay'),
            ),
          ],
        ),
      ),
    );
  }
}
