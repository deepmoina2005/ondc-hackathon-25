import 'package:flutter/material.dart';

class VendorAuthScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Vendor Login'),
        centerTitle: true, // Centering the title
        backgroundColor: Colors.teal, // Customizing the app bar color
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Welcome Back!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.teal,
              ),
            ),
            SizedBox(height: 20),
            TextField(
              decoration: InputDecoration(
                labelText: 'Email Address',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.email), // Adding an icon
              ),
              keyboardType: TextInputType.emailAddress, // Input type hint
            ),
            SizedBox(height: 15),
            TextField(
              decoration: InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.lock), // Adding an icon
              ),
              obscureText: true, // Secure text input
            ),
            SizedBox(height: 25),
            ElevatedButton(
              onPressed: () {
                // Add authentication logic here
                print('Login Button Pressed');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal, // Custom button color
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
              ),
              child: Text('Sign In'),
            ),
            SizedBox(height: 15),
            TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/vendor_signup');
              },
              child: Text(
                'New here? Create an Account',
                style: TextStyle(color: Colors.teal), // Matching theme color
              ),
            ),
          ],
        ),
      ),
    );
  }
}
