import 'package:flutter/material.dart';
import 'package:apex_code_ki_dukaan_flutter_vscode/localization/app_localizations.dart'; // Ensure this file exists or update the path
// If the file doesn't exist, create it or update the path accordingly

class HomeScreen extends StatelessWidget {
  final Function(Locale) changeLanguage;

  const HomeScreen({Key? key, required this.changeLanguage}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)?.title ?? 'Title'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (String value) {
              if (value == 'en') {
                changeLanguage(const Locale('en'));
              } else if (value == 'hi') {
                changeLanguage(const Locale('hi'));
              } else if (value == 'mr') {
                changeLanguage(const Locale('mr'));
              }
            },
            itemBuilder: (BuildContext context) {
              return [
                const PopupMenuItem<String>(
                  value: 'en',
                  child: Text('English'),
                ),
                const PopupMenuItem<String>(
                  value: 'hi',
                  child: Text('हिंदी'),
                ),
                const PopupMenuItem<String>(
                  value: 'mr',
                  child: Text('मराठी'),
                ),
              ];
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(AppLocalizations.of(context)?.welcome ?? 'Welcome'),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/consumer_login');
              },
              child: Text(AppLocalizations.of(context)?.login ?? 'Login'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/consumer_signup');
              },
              child: Text(AppLocalizations.of(context)?.signup ?? 'Signup'),
            ),
          ],
        ),
      ),
    );
  }
}
