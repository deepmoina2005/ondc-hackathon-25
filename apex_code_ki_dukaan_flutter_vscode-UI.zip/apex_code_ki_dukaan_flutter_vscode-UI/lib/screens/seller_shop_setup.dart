import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

class SellerShopSetup extends StatefulWidget {
  @override
  _SellerShopSetupState createState() => _SellerShopSetupState();
}

class _SellerShopSetupState extends State<SellerShopSetup> {
  final TextEditingController shopNameController = TextEditingController();
  final TextEditingController shopAddressController = TextEditingController();
  final List<String> goodsTypes = [
    'Grocery',
    'Electronics',
    'Clothing',
    'Others'
  ];
  String? selectedGoodsType;
  File? shopImage;
  final picker = ImagePicker();

  Future<void> uploadShopDetails() async {
    try {
      final userId = FirebaseAuth.instance.currentUser!.uid;
      String? imageUrl;

      if (shopImage != null) {
        final ref = FirebaseStorage.instance.ref().child('shops/$userId.jpg');
        await ref.putFile(shopImage!);
        imageUrl = await ref.getDownloadURL();
      }

      await FirebaseFirestore.instance.collection('shops').doc(userId).set({
        'shopName': shopNameController.text.trim(),
        'shopAddress': shopAddressController.text.trim(),
        'goodsType': selectedGoodsType,
        'shopImage': imageUrl,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content:
                Text('Shop setup complete! Redirecting to add products...')),
      );

      Navigator.pushNamed(context, '/addProducts');
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
    }
  }

  Future<void> pickShopImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        shopImage = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Setup Your Shop')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: shopNameController,
                decoration: InputDecoration(
                  labelText: 'Shop Name',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: shopAddressController,
                decoration: InputDecoration(
                  labelText: 'Shop Address',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: selectedGoodsType,
                hint: Text('Select Goods Type'),
                items: goodsTypes.map((type) {
                  return DropdownMenuItem<String>(
                    value: type,
                    child: Text(type),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedGoodsType = value;
                  });
                },
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: pickShopImage,
                child: Text('Upload Shop Photo'),
              ),
              shopImage != null
                  ? Image.file(shopImage!,
                      height: 150, width: 150, fit: BoxFit.cover)
                  : SizedBox(),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: uploadShopDetails,
                child: Text('Save and Continue'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
