import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';

String? imageUrl;

class SellerAddProduct extends StatefulWidget {
  @override
  _SellerAddProductState createState() => _SellerAddProductState();
}

class _SellerAddProductState extends State<SellerAddProduct> {
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController productPriceController = TextEditingController();
  File? productImage;
  final picker = ImagePicker();

  Future<void> uploadProduct() async {
    try {
      final userId = FirebaseAuth.instance.currentUser!.uid;
      String? imageUrl;

      if (productImage != null) {
        final ref = FirebaseStorage.instance
            .ref()
            .child('products/$userId/${DateTime.now()}.jpg');
        await ref.putFile(productImage!);
        imageUrl = await ref.getDownloadURL();
      }

      await FirebaseFirestore.instance.collection('products').add({
        'sellerId': userId,
        'productName': productNameController.text.trim(),
        'productPrice': productPriceController.text.trim(),
        'productImage': imageUrl,
      });

      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Product added successfully!')));
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
    }
  }

  Future<void> pickProductImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        productImage = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Product')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: productNameController,
                decoration: InputDecoration(
                  labelText: 'Product Name',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: productPriceController,
                decoration: InputDecoration(
                  labelText: 'Price (per kg, gram, piece, etc.)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: pickProductImage,
                child: Text('Upload Product Photo'),
              ),
              productImage != null
                  ? Image.file(productImage!,
                      height: 150, width: 150, fit: BoxFit.cover)
                  : SizedBox(),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: uploadProduct,
                child: Text('Add Product'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
