import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  Map<String, Map<String, String>> _localizedStrings = {
    'en': {
      'title': 'Marketplace App',
      'welcome': 'Welcome!',
      'login': 'Login',
      'signup': 'Signup',
    },
    'hi': {
      'title': 'मार्केटप्लेस ऐप',
      'welcome': 'स्वागत है!',
      'login': 'लॉग इन करें',
      'signup': 'साइन अप करें',
    },
    'mr': {
      'title': 'मार्केटप्लेस अॅप',
      'welcome': 'स्वागत आहे!',
      'login': 'लॉगिन',
      'signup': 'साइन अप करा',
    },
  };

  String get title => _localizedStrings[locale.languageCode]!['title']!;
  String get welcome => _localizedStrings[locale.languageCode]!['welcome']!;
  String get login => _localizedStrings[locale.languageCode]!['login']!;
  String get signup => _localizedStrings[locale.languageCode]!['signup']!;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'hi', 'mr'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return SynchronousFuture<AppLocalizations>(AppLocalizations(locale));
  }

  @override
  bool shouldReload(covariant LocalizationsDelegate<AppLocalizations> old) => false;
}
