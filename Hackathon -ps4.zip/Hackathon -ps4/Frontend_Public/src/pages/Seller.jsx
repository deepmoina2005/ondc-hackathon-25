import Footer from '@/components/Footer'
import Navbar from '@/components/Navbar/Navbar'
import React from 'react'

const Seller = () => {
  return (
    <div>
      <Navbar/>
      <Footer/>
    </div>
  )
}

export default Seller