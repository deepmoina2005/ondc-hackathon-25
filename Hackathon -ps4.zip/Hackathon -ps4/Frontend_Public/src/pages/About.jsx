import Footer from '@/components/Footer'
import Navbar from '@/components/Navbar/Navbar'
import React from 'react'

const About = () => {
  return (
    <div>
      <Navbar/>
      <Footer/>
    </div>
  )
}

export default About