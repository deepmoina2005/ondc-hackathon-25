import { v2 as cloudinary } from 'cloudinary';
function cloudinary() {

}

// export default cloudinary

