import React from 'react'
import './Navbar.css'
function Navbar() {
  return (
  <>
    <nav>
      <div className="nav-text">
      <h1>Hello <span>Super Admin</span></h1>
      </div>
    </nav>
  </>
  )
}

export default Navbar
