import express from 'express'

const sellerRouter = express.Router();

export default sellerRouter;