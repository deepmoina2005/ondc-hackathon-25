package com.wackyhacky.ondchackathonprototype;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("E-Dukaan");

        BottomNavigationView bnView = findViewById(R.id.bottomNavigationView);

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.container, new HomeFragment());
        ft.commit();
        bnView.setSelectedItemId(R.id.nav_Home);

        bnView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                FragmentTransaction ft;
                if (id == R.id.nav_Home) {
                    ft = fm.beginTransaction();
                    ft.replace(R.id.container, new HomeFragment());
                    ft.commit();
                }
                else if (id == R.id.nav_catalog) {
                    ft = fm.beginTransaction();
                    ft.replace(R.id.container, new CatalogFragment());
                    ft.commit();
                }
                else if (id == R.id.nav_profile) {
                    ft = fm.beginTransaction();
                    ft.replace(R.id.container, new ProfileFragment());
                    ft.commit();
                }
                return true;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        menu.findItem(R.id.helpBtn).getIcon().setTint(getResources().getColor(R.color.white));
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.helpBtn){
            startActivity(new Intent(MainActivity.this, HelpActivity.class));
        }
        return true;
    }
}