package com.wackyhacky.ondchackathonprototype;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class HelpActivity extends AppCompatActivity {

    private ExpandableListView expandableListView;
    private ExpandableListAdapter expandableListAdapter;
    private List<String> questionList; // List of questions
    private HashMap<String, List<String>> answerMap; // Map of questions and their respective answers (like video links or images)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        expandableListView = findViewById(R.id.expandableListView);

        // Prepare data
        prepareData();

        // Set the adapter
        expandableListAdapter = new CustomExpandableListAdapter(this, questionList, answerMap);
        expandableListView.setAdapter(expandableListAdapter);

        // Set item click listener to show more content (e.g., video links, images)
        expandableListView.setOnChildClickListener((parent, v, groupPosition, childPosition, id) -> {
            String selectedAnswer = answerMap.get(questionList.get(groupPosition)).get(childPosition);
            Toast.makeText(HelpActivity.this, "Selected: " + selectedAnswer, Toast.LENGTH_SHORT).show();
            return false;
        });
    }

    private void prepareData() {
        questionList = new ArrayList<>();
        answerMap = new HashMap<>();

        // Add questions
        questionList.add("How to add a product?");
        questionList.add("How to manage stock?");
        questionList.add("How to view sales reports?");
        questionList.add("How to update product details?");

        // Add answers (for now, placeholders for video/image links)
        List<String> addProductAnswers = new ArrayList<>();
        addProductAnswers.add("Video Tutorial for Adding Products");
        addProductAnswers.add("Guide on Adding Products");

        List<String> manageStockAnswers = new ArrayList<>();
        manageStockAnswers.add("Video Tutorial for Managing Stock");
        manageStockAnswers.add("Stock Management Guide");

        List<String> salesReportsAnswers = new ArrayList<>();
        salesReportsAnswers.add("Link to Sales Reports");
        salesReportsAnswers.add("How to view sales reports");

        List<String> updateProductAnswers = new ArrayList<>();
        updateProductAnswers.add("Tutorial for Updating Product Details");
        updateProductAnswers.add("Guide on Editing Product Information");

        // Putting the questions and answers in the map
        answerMap.put(questionList.get(0), addProductAnswers);
        answerMap.put(questionList.get(1), manageStockAnswers);
        answerMap.put(questionList.get(2), salesReportsAnswers);
        answerMap.put(questionList.get(3), updateProductAnswers);
    }

    // Handle the back button in the action bar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
