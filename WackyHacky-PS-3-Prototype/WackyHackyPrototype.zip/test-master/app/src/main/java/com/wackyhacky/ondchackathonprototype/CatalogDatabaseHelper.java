package com.wackyhacky.ondchackathonprototype;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CatalogDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CatalogDB";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "catalog";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_CATEGORY = "category";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_STOCK = "stock";
    private static final String COLUMN_REMARKS = "remarks";

    public CatalogDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_CATEGORY + " TEXT, " +
                COLUMN_DESCRIPTION + " TEXT, " +
                COLUMN_PRICE + " REAL, " +
                COLUMN_STOCK + " INTEGER, " +
                COLUMN_REMARKS + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addProductToCatalog(Product product) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if product already exists based on its name (or any other unique identifier)
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_NAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{product.getName()});

        // If the product exists, update its stock, otherwise insert a new entry
        if (cursor != null && cursor.moveToFirst()) {
            int existingStock = cursor.getInt(cursor.getColumnIndex(COLUMN_STOCK));
            int newStock = existingStock + product.getStock(); // Increase stock
            ContentValues values = new ContentValues();
            values.put(COLUMN_STOCK, newStock);
            db.update(TABLE_NAME, values, COLUMN_NAME + " = ?", new String[]{product.getName()});
            cursor.close();
        } else {
            // Product doesn't exist, insert a new entry
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME, product.getName());
            values.put(COLUMN_CATEGORY, product.getCategory());
            values.put(COLUMN_DESCRIPTION, product.getDescription());
            values.put(COLUMN_PRICE, product.getPrice());
            values.put(COLUMN_STOCK, product.getStock());
            values.put(COLUMN_REMARKS, product.getRemarks());
            db.insert(TABLE_NAME, null, values);
        }

        db.close();
    }

    public Cursor getAllCatalogProducts() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
    public void updateProductStock(String productName, int newStock) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_STOCK, newStock);
        db.update(TABLE_NAME, values, COLUMN_NAME + " = ?", new String[]{productName});
        db.close();
    }
    public void deleteProduct(String productName) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_NAME + " = ?", new String[]{productName});
        db.close();
    }
}
