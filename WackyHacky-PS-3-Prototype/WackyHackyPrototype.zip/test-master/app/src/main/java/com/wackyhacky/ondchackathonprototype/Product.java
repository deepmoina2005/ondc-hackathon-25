package com.wackyhacky.ondchackathonprototype;
public class Product {
    private String name;
    private String category;
    private String description;
    private double price;
    private int stock;
    private String remarks;

    public Product(String name, String category, String description, double price) {
        this.name = name;
        this.category = category;
        this.description = description;
        this.price = price;
        this.stock = 0; // Default stock
        this.remarks = ""; // Default remarks
    }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    // Getters and setters for stock and remarks
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public void setPrice(double price) {
        this.price = price;
    }
}
