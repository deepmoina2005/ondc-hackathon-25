package com.wackyhacky.ondchackathonprototype;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CatalogAdapter extends RecyclerView.Adapter<CatalogAdapter.CatalogViewHolder> {

    private List<Product> catalogList;
    private Context context;
    private CatalogDatabaseHelper dbHelper;
    private HomeFragment homeFragment;

    public CatalogAdapter(List<Product> catalogList, Context context, CatalogDatabaseHelper dbHelper, HomeFragment homeFragment) {
        this.catalogList = catalogList;
        this.context = context;
        this.dbHelper = dbHelper;
        this.homeFragment = homeFragment;  // Store the HomeFragment instance
    }

    @NonNull
    @Override
    public CatalogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new CatalogViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CatalogViewHolder holder, int position) {
        Product product = catalogList.get(position);
        holder.productNameTextView.setText(product.getName());
        holder.productCategoryTextView.setText(product.getCategory());
        holder.productDescriptionTextView.setText(product.getDescription());

        // Handle the stock visibility and color
        String stockText = "Stock: " + product.getStock();
        holder.productStockTextView.setText(stockText);

        if (product.getStock() <= 5) {
            holder.productStockTextView.setVisibility(View.VISIBLE);
            holder.productStockTextView.setTextColor(Color.RED); // Red for low stock
        } else {
            holder.productStockTextView.setVisibility(View.VISIBLE);
            holder.productStockTextView.setTextColor(Color.GREEN); // Green for enough stock
        }

        holder.addButton.setVisibility(View.GONE);

        // Set up a click listener for updating stock sold
        holder.itemView.setOnClickListener(v -> showStockUpdateDialog(product));

        // Set up a long-click listener for deleting the item
        holder.itemView.setOnLongClickListener(v -> {
            showDeleteConfirmationDialog(product, position);
            return true;
        });
    }

    private void showDeleteConfirmationDialog(Product product, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Delete Product")
                .setMessage("Are you sure you want to delete " + product.getName() + "?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    // Delete product from database
                    dbHelper.deleteProduct(product.getName());

                    // Remove product from the list and notify adapter
                    catalogList.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, catalogList.size());

                    // Add recent activity for deletion
                    homeFragment.addRecentActivity("Deleted product: " + product.getName());

                    Toast.makeText(context, product.getName() + " deleted successfully", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void showStockUpdateDialog(Product product) {
        // Create a dialog to input the stock sold
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Stock Sold");

        // Set up the input
        final EditText input = new EditText(context);
        input.setHint("Enter amount sold");
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String inputText = input.getText().toString().trim();
                if (!inputText.isEmpty()) {
                    int soldAmount = Integer.parseInt(inputText);
                    int newStock = product.getStock() - soldAmount;
                    if (newStock >= 0) {
                        // Update stock in database
                        dbHelper.updateProductStock(product.getName(), newStock);
                        product.setStock(newStock);  // Update the product's stock in the list
                        notifyDataSetChanged(); // Refresh the list to show updated stock

                        // Add recent activity for stock update
                        homeFragment.addRecentActivity("Updated stock for: " + product.getName() + " to " + newStock);
                    } else {
                        // Show error if the stock is insufficient
                        Toast.makeText(context, "Insufficient stock available", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    @Override
    public int getItemCount() {
        return catalogList.size();
    }

    public static class CatalogViewHolder extends RecyclerView.ViewHolder {

        TextView productNameTextView, productCategoryTextView, productDescriptionTextView, productStockTextView;
        Button addButton;

        public CatalogViewHolder(@NonNull View itemView) {
            super(itemView);
            productNameTextView = itemView.findViewById(R.id.tv_product_name);
            productCategoryTextView = itemView.findViewById(R.id.tv_product_category);
            productDescriptionTextView = itemView.findViewById(R.id.tv_product_description);
            productStockTextView = itemView.findViewById(R.id.tv_product_stock); // Referencing stock TextView
            addButton = itemView.findViewById(R.id.btn_add);
        }
    }
}