package com.wackyhacky.ondchackathonprototype;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {

    private EditText passwordEditText, emailEditText;
    private ImageButton togglePasswordVisibility;
    private boolean isPasswordVisible = false;

    private static final String CORRECTEMAIL = "test@admin.com";
    private static final String CORRECTPASSWORD = "123456";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setTitle("E-Dukaan");

        emailEditText = findViewById(R.id.editTextEmail);
        passwordEditText = findViewById(R.id.editTextPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        togglePasswordVisibility = findViewById(R.id.btnTogglePasswordVisibility);

        togglePasswordVisibility.setOnClickListener(v -> togglePasswordVisibility());

        btnLogin.setOnClickListener(v -> login());
    }

    private void login() {
        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        if(email.isEmpty() || password.isEmpty()){
            Toast.makeText(this, "Email and Password can not be empty", Toast.LENGTH_SHORT).show();
        } else if(!email.equals(CORRECTEMAIL) || !password.equals(CORRECTPASSWORD)){
            Toast.makeText(this, "Incorrect email or password", Toast.LENGTH_SHORT).show();
        } else{
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
    }

    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            togglePasswordVisibility.setImageResource(R.drawable.baseline_show_24); // Change to hide icon
        } else {
            passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            togglePasswordVisibility.setImageResource(R.drawable.baseline_hide_24); // Change to show icon
        }
        passwordEditText.setSelection(passwordEditText.length());
        isPasswordVisible = !isPasswordVisible;
    }
}