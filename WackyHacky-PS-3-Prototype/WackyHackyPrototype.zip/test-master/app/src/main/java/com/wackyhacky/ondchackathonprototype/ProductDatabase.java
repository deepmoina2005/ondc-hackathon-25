package com.wackyhacky.ondchackathonprototype;

import java.util.ArrayList;
import java.util.List;

public class ProductDatabase {
    public static List<Product> getProductList() {
        List<Product> products = new ArrayList<>();
        products.add(new Product("Kurkure Masala Munch", "Snacks", "Crunchy and spicy snack", 10.0));
        products.add(new Product("Kurkure Green Chutney", "Snacks", "Zesty and flavorful snack", 12.0));
        products.add(new Product("Lay's Classic", "Snacks", "Classic salted potato chips", 20.0));
        products.add(new Product("Lay's Magic Masala", "Snacks", "Spicy Indian masala chips", 25.0));
        products.add(new Product("Dairy Milk Silk", "Chocolate", "Smooth and creamy chocolate bar", 70.0));
        products.add(new Product("KitKat", "Chocolate", "Crispy wafer chocolate", 50.0));
        products.add(new Product("Oreo Biscuits", "Biscuits", "Chocolate sandwich biscuits", 30.0));
        return products;
    }
}
