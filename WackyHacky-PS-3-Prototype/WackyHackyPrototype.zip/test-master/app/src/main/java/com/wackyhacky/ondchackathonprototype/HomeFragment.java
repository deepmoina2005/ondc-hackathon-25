package com.wackyhacky.ondchackathonprototype;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private CatalogAdapter adapter;
    private CatalogDatabaseHelper dbHelper;
    private List<Product> catalogList;
    private TextView totalProductsTextView;
    private TextView lowStockAlertTextView;
    private LinearLayout recentActivityLayout;

    private List<String> recentActivities;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recycler_view);
        totalProductsTextView = view.findViewById(R.id.tv_total_products);
        lowStockAlertTextView = view.findViewById(R.id.tv_low_stock_alert);
        recentActivityLayout = view.findViewById(R.id.ll_recent_activity);

        dbHelper = new CatalogDatabaseHelper(getContext());

        catalogList = new ArrayList<>();
        recentActivities = new ArrayList<>();

        loadCatalogFromDatabase();

        // Set up RecyclerView for catalog list
        adapter = new CatalogAdapter(catalogList, getContext(), dbHelper, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        // Display stats and recent activities
        displayStatsAndActivities();

        return view;
    }

    private void loadCatalogFromDatabase() {
        Cursor cursor = dbHelper.getAllCatalogProducts();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndex("name"));
                String category = cursor.getString(cursor.getColumnIndex("category"));
                String description = cursor.getString(cursor.getColumnIndex("description"));
                double price = cursor.getDouble(cursor.getColumnIndex("price"));
                int stock = cursor.getInt(cursor.getColumnIndex("stock"));
                String remarks = cursor.getString(cursor.getColumnIndex("remarks"));
                Product temp = new Product(name, category, description, price);
                temp.setStock(stock);
                temp.setRemarks(remarks);
                catalogList.add(temp);
            }
            cursor.close();
        } else {
            Toast.makeText(getContext(), "No products in catalog", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayStatsAndActivities() {
        // Display total products
        totalProductsTextView.setText("Total Products: " + catalogList.size());

        // Display low stock alert
        StringBuilder lowStockAlert = new StringBuilder("Low Stock Alerts: \n");
        for (Product product : catalogList) {
            if (product.getStock() <= 5) {
                lowStockAlert.append(product.getName()).append(": ").append(product.getStock()).append(" in stock\n");
            }
        }
        lowStockAlertTextView.setText(lowStockAlert.toString());

        // Display recent activities
        if (recentActivities.isEmpty()) {
            recentActivityLayout.setVisibility(View.GONE);  // Hide if no activities
        } else {
            recentActivityLayout.setVisibility(View.VISIBLE);

            // Clear previous activity views before adding new ones
            recentActivityLayout.removeAllViews();

            for (String activity : recentActivities) {
                TextView activityTextView = new TextView(getContext());
                activityTextView.setText(activity);
                recentActivityLayout.addView(activityTextView);
            }
        }
    }


    // Method to add recent activities (such as updates, deletions, etc.)
    public void addRecentActivity(String activity) {
        recentActivities.add(activity);
        displayStatsAndActivities(); // Update UI with the new activity
    }
}