package com.wackyhacky.ondchackathonprototype;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

public class CustomExpandableListAdapter extends BaseExpandableListAdapter {

    private Context context;
    private List<String> questionList; // List of questions
    private HashMap<String, List<String>> answerMap; // Map of questions and their respective answers

    public CustomExpandableListAdapter(Context context, List<String> questionList, HashMap<String, List<String>> answerMap) {
        this.context = context;
        this.questionList = questionList;
        this.answerMap = answerMap;
    }

    @Override
    public int getGroupCount() {
        return questionList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return answerMap.get(questionList.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return questionList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return answerMap.get(questionList.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.list_item_question, null);  // Custom layout for the group
        }

        TextView questionTextView = convertView.findViewById(R.id.text1);
        questionTextView.setText(questionList.get(groupPosition));

        // Apply bold text style and padding to make the question take up more space
        questionTextView.setTypeface(null, android.graphics.Typeface.BOLD);
        questionTextView.setPadding(32, 32, 32, 32);  // Add padding around the question

        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.list_item_answer, null);  // Custom layout for child items
        }

        TextView answerTextView = convertView.findViewById(R.id.text1);
        answerTextView.setText(answerMap.get(questionList.get(groupPosition)).get(childPosition));

        // Style for the answer text
        answerTextView.setPadding(48, 16, 48, 16);  // Extra padding for answers
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
