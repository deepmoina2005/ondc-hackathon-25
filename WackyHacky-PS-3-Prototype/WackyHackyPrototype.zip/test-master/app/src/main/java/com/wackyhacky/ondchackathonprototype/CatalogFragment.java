package com.wackyhacky.ondchackathonprototype;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CatalogFragment extends Fragment {

    private EditText searchInput;
    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private List<Product> productList;
    private CatalogDatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_catalog, container, false);

        searchInput = view.findViewById(R.id.search_input);
        recyclerView = view.findViewById(R.id.recycler_view);

        dbHelper = new CatalogDatabaseHelper(getContext());
        productList = ProductDatabase.getProductList();

        adapter = new ProductAdapter(productList, this::showProductDialog);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        view.findViewById(R.id.btn_search).setOnClickListener(v -> performSearch());

        return view;
    }

    private void performSearch() {
        String query = searchInput.getText().toString().toLowerCase();
        List<Product> filteredList = new ArrayList<>();
        for (Product product : productList) {
            if (product.getName().toLowerCase().contains(query)) {
                filteredList.add(product);
            }
        }
        if (filteredList.isEmpty()) {
            Toast.makeText(getContext(), "No products found", Toast.LENGTH_SHORT).show();
        }
        adapter.updateList(filteredList);
    }

    private void showProductDialog(Product product) {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_product, null);
        EditText stockInput = dialogView.findViewById(R.id.input_stock);
        EditText priceInput = dialogView.findViewById(R.id.input_price);
        EditText remarksInput = dialogView.findViewById(R.id.input_remarks);

        new AlertDialog.Builder(getContext())
                .setTitle("Add Product to Catalog")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String stockText = stockInput.getText().toString();
                    String priceText = priceInput.getText().toString();

                    if (TextUtils.isEmpty(stockText) || TextUtils.isEmpty(priceText)) {
                        Toast.makeText(getContext(), "Stock and Price are required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int stock = Integer.parseInt(stockText);
                    double price = Double.parseDouble(priceText);
                    String remarks = remarksInput.getText().toString();

                    product.setStock(stock);
                    product.setPrice(price);
                    product.setRemarks(remarks);

                    dbHelper.addProductToCatalog(product);
                    Toast.makeText(getContext(), product.getName() + " added to catalog", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
