# ONDC Hackathon Prototype

This repository contains the ONDC (Open Network for Digital Commerce) Hackathon Prototype, a sample Android application built to demonstrate features like product catalog management, sorting, filtering, and search functionalities.

---

## Features

1. **Product Catalog Management:**
    
    - Add, update, and delete products in the catalog.
        
    - View detailed product information including name, category, description, price, stock, and remarks.
        
2. **Search Functionality:**
    
    - Search for products using a search bar in the CatalogFragment.
        
    - Results are dynamically updated based on the search query.
        
3. **Recent Activities:**
    
    - Track actions such as adding or deleting products.
        
    - Recent activities are dynamically updated and displayed.
        
4. **Stock Management:**
    
    - Update stock levels.
        
    - Highlight low stock products with alerts.
        

---

## Getting Started

### Prerequisites

1. Android Studio (Arctic Fox or newer)
    
2. Android SDK 21 or higher
    
3. A device or emulator for testing
    

### Installation

1. Clone this repository:
    
    ```
    git clone https://github.com/your-repo/ondc-hackathon-prototype.git
    ```
    
2. Open the project in Android Studio.
    
3. Sync the Gradle files and resolve dependencies.
    
4. Run the app on an emulator or physical device.
    

---

## How to Use

1. **Home Screen:**
    
    - View the catalog and recent activities.
        
    - Use the search bar to find specific products.
        
    - Apply filters and sort options.
        
2. **Add Product:**
    
    - Go to Catalog Fragment and search for a product you want to add.
        
3. **Edit Product:**
    
    - Tap on an existing product in the Home Fragment to update its stock.
        
4. **Delete Product:**
    
    - Long-press a product to delete it from the catalog.
        

---

## Technical Details

- **Programming Language:** Java
    
- **Database:** SQLite using `CatalogDatabaseHelper`
    
- **Android Version Compatibility:** API Level 21 and above
    

---

## Future Improvements

1. Implement ONDC Onboarding registration. 
    
2. Implement network integration for syncing with an online database.
    
3. Enhance UI/UX with Material Design components.
    
4. Add advanced analytics and reporting features.
    

---